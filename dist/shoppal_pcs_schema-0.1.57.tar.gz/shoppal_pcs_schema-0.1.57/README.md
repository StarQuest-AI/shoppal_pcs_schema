# shoppal_pcs_schema
shoppal_pcs_schema


## jsonschema to avro

### infer avro schema from json data

https://konbert.com/convert/json/to/avro
